public class Expression extends ExpressionTree {
   
   public String fullyParenthesized() {
      // add implementation here
      return "";
   }

   public Expression(String s) {
      super();
      // add implementation here
   }
   
   public double evaluate() {
      // add implementation here
      return 0.0;
   }
}
